This is a template repo for coursework on pipelines using the targets package
